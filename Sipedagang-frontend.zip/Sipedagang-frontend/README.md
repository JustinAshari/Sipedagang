<p align="center">
  <img src="./src/assets/svg/LOGO.svg" alt="SiPEDAGANG Logo" width="180"/>
</p>

<h1 align="center">PROJECT FRONTEND SiPEDAGANG</h1>

<p align="center">
  <b>SiPEDAGANG</b> (Sistem Pembayaran Pengadaan Gabah Beras Gudang) adalah sistem informasi yang dikembangkan untuk mendukung proses pengadaan beras dan gabah oleh <b>Perum BULOG</b> secara digital dan terintegrasi.<br>
  Sistem ini bertujuan untuk memfasilitasi pencatatan data pembelian gabah dan beras dari petani atau mitra secara efisien, transparan, dan akuntabel.
</p>

---
