<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="9"
    height="14"
    viewBox="0 0 9 14"
    fill="none"
  >
    <path
      d="M1.46313 1C1.46313 1 7.46312 5.4189 7.46313 7C7.46314 8.5812 1.46313 13 1.46313 13"
      stroke="#9BA1AA"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
