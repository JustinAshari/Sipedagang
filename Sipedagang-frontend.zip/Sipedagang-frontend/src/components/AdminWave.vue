<template>
  <div class="absolute top-0 left-0 right-0 z-0">
    <svg
      width="100%"
      height="120"
      preserveAspectRatio="none"
      viewBox="0 0 1514 173"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      class="sm:h-[140px] md:h-[160px] lg:h-[173px] transition-all duration-300"
    >
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M1514 142.27V173C1489.62 160.399 1440.3 100.191 1143.36 104.5C1019.81 104.5 997.051 54 868.084 48.5C744.537 44.679 620.989 71.4258 497.442 48.5C373.894 25.5742 63.9413 5.12171 0 0H93.2025C154.976 0 278.524 0 402.072 0C525.619 0 649.167 0 772.714 0C896.262 0 1019.81 0 1143.36 0C1266.9 0 1390.45 0 1452.23 0H1514V142.27Z"
        fill="url(#gradient-top)"
      />
      <defs>
        <linearGradient id="gradient-top" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" style="stop-color: #0099ff; stop-opacity: 1" />
          <stop offset="50%" style="stop-color: #176bc7; stop-opacity: 1" />
          <stop offset="100%" style="stop-color: #1e40af; stop-opacity: 1" />
        </linearGradient>
      </defs>
    </svg>
  </div>
  <div class="absolute bottom-0 left-0 z-0 w-1/2 sm:w-1/3 md:w-auto">
    <svg
      width="100%"
      height="60"
      preserveAspectRatio="none"
      viewBox="0 0 548 105"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      class="sm:h-[80px] md:h-[90px] lg:h-[105px] transition-all duration-300"
    >
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M548 105.271H499.5C476.5 108.5 434.546 88.9172 391.092 86.1614C347.637 83.6812 304.182 73.5796 260.728 57.596C217.273 41.8881 173.818 9.92093 130.364 2.20472C86.9092 -5.78706 43.4546 9.92093 21.7273 17.9127L0 25.9045V105.271H21.7273C43.4546 105.271 86.9092 105.271 130.364 105.271C173.818 105.271 217.273 105.271 260.728 105.271C304.182 105.271 347.637 105.271 391.092 105.271C434.546 105.271 478 104.776 499.5 105.271H521.455H548Z"
        fill="url(#gradient-bottom-left)"
      />
      <defs>
        <linearGradient
          id="gradient-bottom-left"
          x1="0%"
          y1="0%"
          x2="100%"
          y2="0%"
        >
          <stop offset="0%" style="stop-color: #f0ab26; stop-opacity: 1" />
          <stop offset="100%" style="stop-color: #f59e0b; stop-opacity: 1" />
        </linearGradient>
      </defs>
    </svg>
  </div>
  <div class="absolute bottom-0 right-0 z-0 w-2/3 md:w-auto">
    <svg
      width="100%"
      height="90"
      preserveAspectRatio="none"
      viewBox="0 0 1051 157"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      class="sm:h-[120px] md:h-[140px] lg:h-[157px] transition-all duration-300"
    >
      <path
        d="M1051 157H0.602539C29.1097 153.456 59.8947 149.303 90.6797 144.537C170.706 132.148 250.733 115.63 330.76 103.241C410.786 90.8523 490.813 82.5923 570.84 90.8516C650.866 99.1108 730.893 123.889 810.92 111.5C890.947 99.1111 970.973 49.5551 1010.99 24.7773L1051 0V157Z"
        fill="url(#gradient-bottom-right)"
      />
      <defs>
        <linearGradient
          id="gradient-bottom-right"
          x1="0%"
          y1="0%"
          x2="100%"
          y2="0%"
        >
          <stop offset="0%" style="stop-color: #1b4f88; stop-opacity: 1" />
          <stop offset="100%" style="stop-color: #1e3a8a; stop-opacity: 1" />
        </linearGradient>
      </defs>
    </svg>
  </div>
</template>
